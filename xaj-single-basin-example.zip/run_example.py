import h5py
import numpy as np
import pandas as pd
import spotpy
import xaj
from spot_xaj import spot_setup
import matplotlib.pyplot as plt


from pathlib import Path
base_dir = Path.cwd()

xajparm_path = base_dir / "parm" / "XAJ_param.txt"
data_force_path =base_dir / "parm" / "data_forcing.txt"
Q_obs_path = base_dir / "parm" / "Q_obs.txt"



data=pd.read_excel("data_input.xlsx",sheet_name=["Pre", "ET","Surrogate_Streamflow","Basin_area"]);
pre = data["Pre"]['Pre(mm/day)'].to_numpy(dtype=np.float64)
et= data["ET"]['et0 (mm/day)'].to_numpy(dtype=np.float64)
q_obs = data["Surrogate_Streamflow"]['streamflow (m3/s)'].to_numpy(dtype=np.float64)
area = data["Basin_area"]['basin_areas/km2'].to_numpy(dtype=np.float64)
flag_num = data["Surrogate_Streamflow"]['train (1), test(0)'].to_numpy(dtype=np.float64)


indices = np.where(flag_num == 1)[0]
data_forcing = np.empty((2922,3),dtype=np.float32)
data_forcing[0:2922,0] = pre
data_forcing[0:2922,1] = et
data_forcing[0,2] = area
q_obs_slected = np.empty((len(indices),2),dtype=np.float32)
q_obs_slected[:,0] = q_obs[indices]
q_obs_slected[:,1] = indices[:]
np.savetxt(data_force_path, data_forcing, fmt='%.18e', delimiter=' ', newline='\n', header='', footer='', comments='# ')
np.savetxt(Q_obs_path, q_obs_slected, fmt='%.18e', delimiter=' ', newline='\n', header='', footer='', comments='# ')
del data_forcing,q_obs_slected,indices

spot_setup = spot_setup()
rep = 1000
nChains = 4
runs_after_convergence = 100
np.random.seed(42)
sampler = spotpy.algorithms.sceua(spot_setup, dbname='SCEUA_xaj', dbformat='csv')
nash_max,parms = sampler.sample(rep)

predict_q = xaj.lumped_xaj(pre,et,area,parms)
predict_q=predict_q[365:2922]

t = np.arange(len(q_obs))
plt.figure(figsize=(10, 4))
plt.plot(t, q_obs, color='black', lw=1.5, label='Observed')
plt.plot(t, predict_q, color='red',   lw=1.2, label='Simulated')

plt.xlabel('Time step')
plt.ylabel('Streamflow')
plt.legend()
plt.title('Observed vs Simulated Streamflow')

plt.tight_layout()
plt.show()


