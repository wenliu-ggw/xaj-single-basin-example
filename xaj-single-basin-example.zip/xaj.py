def lumped_xaj(p,e0,f,parameters):
    """单元集总式新安江模型，这版本参数输入变一下"""
    import numpy as np
    # parameters K C B EX SM KG CG CI IM WUM WLM WDM l cs
    # states WU0 WL0 WD0 S10
    k,c,b,ex,sm,kg = parameters[0],parameters[1],parameters[2],parameters[3],parameters[4],parameters[5]
    cg,ci,im,wum,wlm,wdm = parameters[6],parameters[7],parameters[8],parameters[9],parameters[10],parameters[11]
    wm=wdm+wum+wlm
    l,cs = int(parameters[12]),parameters[13]
    
    u=f/(3.6*24)
    ep=k*e0
    ki=0.7-kg
    wmm,smm,num = (1+b)*wm/(1-im),(1+ex)*sm,len(e0)
    
    s1 = np.zeros(num+1,dtype=float,order='c')
    fr = np.zeros(num+1,dtype=float,order='c')
    eu = np.zeros(num+1,dtype=float,order='c')
    el = np.zeros(num+1,dtype=float,order='c')
    ed = np.zeros(num+1,dtype=float,order='c')
    e = np.zeros(num+1,dtype=float,order='c')
    wu = np.zeros(num+1,dtype=float,order='c')
    wl = np.zeros(num+1,dtype=float,order='c')
    wd = np.zeros(num+1,dtype=float,order='c')
    w = np.zeros(num+1,dtype=float,order='c')
    r = np.zeros(num+1,dtype=float,order='c')
    rs3 = np.zeros(num+1,dtype=float,order='c')
    ri3 = np.zeros(num+1,dtype=float,order='c')
    rg3 = np.zeros(num+1,dtype=float,order='c')
    pe = np.zeros(num+1,dtype=float,order='c')
    qi3 = np.zeros(num+1,dtype=float,order='c')
    qg3 = np.zeros(num+1,dtype=float,order='c')
    q3 = np.zeros(num+1,dtype=float,order='c')
    
    wu[0],wl[0],wd[0],s1[0] = 0,wlm*(2/3),wdm,0
    w[0] = wu[0]+wl[0]+wd[0]
    a0 = wmm*(1-(1-w[0]/wm)**(1/(1+b)))
    fr0=1-(1-im)*(1-a0/wmm)**b
    for i in range(0,num):
        if wu[i]+p[i]>=ep[i]:
            eu[i],el[i],ed[i] = ep[i],0,0
        elif wl[i]>=c*wlm:
            eu[i] = wu[i]+p[i]
            el[i] = (ep[i]-eu[i])*wl[i]/wlm;
            ed[i] = 0
        elif wl[i]>=c*(ep[i]-(wu[i]+p[i])):
            eu[i] = wu[i]+p[i]
            el[i],ed[i] = c*(ep[i]-eu[i]),0
        elif wd[i]>=c*(ep[i]-eu[i]-el[i]):
            eu[i],el[i] = wu[i]+p[i],wl[i]
            ed[i] = c*(ep[i]-eu[i]-el[i])
        else:
            eu[i],el[i] = wu[i]+p[i],wl[i]
            ed[i] = wd[i]
        e[i] = eu[i]+el[i]+ed[i]
        pe[i] = p[i]-e[i]
        #三层蒸散发

        #计算总径流
        ratio=w[i]/wm
        if ratio>=1:
            ratio=1
        a = wmm*(1-(1-ratio)**(1/(b+1))); 
        if pe[i]<=0:
            r[i] = 0
        elif a+pe[i]<=wmm:
            r[i] = pe[i]+w[i]-wm+wm*(1-(pe[i]+a)/wmm)**(b+1)
        else:
            r[i] = pe[i]+w[i]-wm
        #计算总径流

        #计算下一时段土壤含水量
        wu[i+1],wl[i+1],wd[i+1] = wu[i]+p[i]-eu[i]-r[i],wl[i]-el[i],wd[i]-ed[i]
        if wu[i+1]>wum:
            wl[i+1],wu[i+1] = wl[i]-el[i]+wu[i+1]-wum,wum
        if wl[i+1]>wlm:
            wd[i+1],wl[i+1] = wd[i]-ed[i]+wl[i+1]-wlm,wlm
        if wd[i+1]>wdm:
            wd[i+1] =wdm      #要不要加个限制wdm不能小于0  感觉需要加一个
        w[i+1] = wu[i+1]+wl[i+1]+wd[i+1]
        #计算下一时段土壤含水量

        #计算产流面积
        if pe[i]>=0.05:
            fr[i]=r[i]/pe[i]; 
        else:
            ratio=(w[i]+w[i+1])/(2*wm)
            if ratio>=1:
                ratio=1
            a0 = wmm*(1-(1-ratio)**(1/(b+1)));
            fr[i] = 1-(1-im)*(1-a0/wmm)**b;
        #计算产流面积
        
        #三分源计算
        if i==0:
            if pe[i]<=0:
                rs3[i],s = 0,s1[i]*fr0/fr[i]
                ri3[i],rg3[i],s1[i+1] = ki*s*fr[i],kg*s*fr[i],s*(1-ki-kg)
            elif r[i]<=5:
                au = smm*(1-(1-(s1[i]*fr0/fr[i])/sm)**(1/(1+ex)))
                if pe[i]+au<smm:
                    rs3[i] = fr[i]*(pe[i]+s1[i]*fr0/fr[i]-sm+sm*(1-(pe[i]+au)/smm)**(ex+1))
                else:
                    rs3[i]=fr[i]*(pe[i]+s1[i]*fr0/fr[i]-sm)
                s=s1[i]*fr0/fr[i]+(r[i]-rs3[i])/fr[i]
                ri3[i],rg3[i],s1[i+1] = ki*s*fr[i],kg*s*fr[i],s*(1-ki-kg)
            else:
                n = int(np.ceil(r[i]/5))
                peint = pe[i]/n
                au = smm*(1-(1-(s1[i]*fr0/fr[i])/sm)**(1/(1+ex)));
                kiint = (1-(1-(ki+kg))**(1/n))/(1+kg/ki)
                kgint = kiint*kg/ki
                sint = s1[i]*fr0/fr[i]
                rs3int = np.zeros(n,dtype=float,order='c')
                ri3int = np.zeros(n,dtype=float,order='c')
                rg3int = np.zeros(n,dtype=float,order='c')
                for j in range(0,n):
                    if peint+au<smm:
                        rs3int[j]=fr[i]*(peint+sint-sm+sm*(1-(peint+au)/smm)**(ex+1))
                    else:
                        rs3int[j]=fr[i]*(peint+sint-sm);
                    sint = sint+(r[i]/n-rs3int[j])/fr[i];  #检查一下
                    ri3int[j],rg3int[j],sint = kiint*sint*fr[i],kgint*sint*fr[i],sint*(1-kiint-kgint)
                    au = smm*(1-(1-sint/sm)**(1/(1+ex)))
                rs3[i],ri3[i],rg3[i] = sum(rs3int),sum(ri3int),sum(rg3int)
                s1[i+1]=sint;
                del rs3int,ri3int,rg3int,n,kiint,kgint,peint,sint,j
        else:
            if pe[i]<=0:
                rs3[i],s = 0,s1[i]*fr[i-1]/fr[i]
                ri3[i],rg3[i],s1[i+1] = ki*s*fr[i],kg*s*fr[i],s*(1-ki-kg)
            elif r[i]<=5:
                au = smm*(1-(1-(s1[i]*fr[i-1]/fr[i])/sm)**(1/(1+ex)))
                if pe[i]+au<smm:
                    rs3[i] = fr[i]*(pe[i]+s1[i]*fr[i-1]/fr[i]-sm+sm*(1-(pe[i]+au)/smm)**(ex+1))
                else:
                    rs3[i]=fr[i]*(pe[i]+s1[i]*fr[i-1]/fr[i]-sm)
                s=s1[i]*fr[i-1]/fr[i]+(r[i]-rs3[i])/fr[i];
                ri3[i],rg3[i],s1[i+1] = ki*s*fr[i],kg*s*fr[i],s*(1-ki-kg)
            elif r[i]>5:
                n = int(np.ceil(r[i]/5))
                peint = pe[i]/n
                au = smm*(1-(1-(s1[i]*fr[i-1]/fr[i])/sm)**(1/(1+ex)));
                kiint = (1-(1-(ki+kg))**(1/n))/(1+kg/ki)
                kgint = kiint*kg/ki
                sint = s1[i]*fr[i-1]/fr[i]
                rs3int = np.zeros(n,dtype=float,order='c')
                ri3int = np.zeros(n,dtype=float,order='c')
                rg3int = np.zeros(n,dtype=float,order='c')
                for j in range(0,n):
                    if peint+au<smm:
                        rs3int[j]=fr[i]*(peint+sint-sm+sm*(1-(peint+au)/smm)**(ex+1))
                    else:
                        rs3int[j]=fr[i]*(peint+sint-sm);
                    sint = sint+(r[i]/n-rs3int[j])/fr[i];
                    ri3int[j],rg3int[j],sint = kiint*sint*fr[i],kgint*sint*fr[i],sint*(1-kiint-kgint)
                    au = smm*(1-(1-sint/sm)**(1/(1+ex)))
                rs3[i],ri3[i],rg3[i] = sum(rs3int),sum(ri3int),sum(rg3int)
                s1[i+1]=sint;
                del rs3int,ri3int,rg3int,n,kiint,kgint,peint,sint,j
#换
    qs3 = rs3*u
    qi3[0] = (1-ci)*ri3[0]*u
    qg3[0] = (1-cg)*rg3[0]*u
    for i in range(1,num):
        qi3[i] = ci*qi3[i-1]+(1-ci)*ri3[i]*u
        qg3[i] = cg*qg3[i-1]+(1-cg)*rg3[i]*u
    q3 = qs3+qi3+qg3
    q = np.zeros(num+1,dtype=float,order='c')
    if l==2:
        q[0] = 0
        q[1] = 0
    elif l==1:
        q[0] = 0
        q[1] = (1-cs)*q3[0]
    else:
        q[0] = (1-cs)*q3[0]
        q[1] = cs*q[0]+(1-cs)*q3[1]
    for i in range(2,num):
        q[i] = cs*q[i-1]+(1-cs)*q3[i-l]
    
    return q[0:num]