#!/usr/bin/env python
# -*- coding: UTF-8 -*-
# author zym
'''目标函数改成f=max(NSE+logNSE)'''
'''此版本按LSTM 的按数据比例划分'''

import spotpy
import xaj
import numpy as np
import os
from pathlib import Path

# 几个关键文件的路径
xajparm_path = Path.cwd() / "parm" / "XAJ_param.txt"
data_force_path =Path.cwd() / "parm" / "data_forcing.txt"
Q_obs_path = Path.cwd() / "parm" / "Q_obs.txt"

# 需要修改的列
change_list = [1, 2, 3 , 4 , 5, 6, 7, 8 ,9 ,10 ,11 ,12 ,13, 14]

class spot_setup():
    def __init__(self,parallel='seq'):
        self.params = [spotpy.parameter.Uniform('K',low=0,high=4,optguess=0.05),
                       spotpy.parameter.Uniform('C',low=0.04,high=0.7,optguess=0.02),
                       spotpy.parameter.Uniform('B',low=0.1,high=2.5,optguess=0.05),
                       spotpy.parameter.Uniform('EX',low=0.01,high=2,optguess=0.05),
                       spotpy.parameter.Uniform('SM',low=5,high=80,optguess=5),
                       spotpy.parameter.Uniform('KG',low=0.05,high=0.68,optguess=0.02),
                       spotpy.parameter.Uniform('CG',low=0.90,high=0.999,optguess=0.001),
                       spotpy.parameter.Uniform('CI',low=0.1,high=0.9,optguess=0.03),
                       spotpy.parameter.Uniform('IM',low=0.001,high=0.10,optguess=0.01),
                       spotpy.parameter.Uniform('WUM',low=5,high=50,optguess=5),
                       spotpy.parameter.Uniform('WLM',low=20,high=120,optguess=10),
                       spotpy.parameter.Uniform('WDM',low=20,high=300,optguess=20),
                       spotpy.parameter.Uniform('L',low=0,high=3,optguess=1),
                       spotpy.parameter.Uniform('CS',low=0.05,high=0.6,optguess=0.05)]
        self.parallel = parallel
        real_value = np.loadtxt(Q_obs_path)[:,0]
        self.real_value = real_value

    def parameters(self):
        return spotpy.parameter.generate(self.params)

    def dc_calculate(self,vec1, vec2):
        '''
        计算确定性系数 3
        :param vec1: array1 
        :param vec2: array2
        :return: dc
        '''
        nash = 1-np.nansum((vec1-vec2)**2)/np.nansum((vec2-np.nanmean(vec2))**2)
        vec2 = np.where(vec2<=1,1,vec2)
        lonash = 1-np.nansum((np.log10(vec1)-np.log10(vec2))**2)/np.nansum((np.log10(vec2)-np.nanmean(np.log10(vec2)))**2)
        dc = (nash+lonash)/2
        return dc 

    def calculate(self,paras):
        '''
        根据参数获取计算流量过程
        :param paras: 参数集
        :return: 计算流量过程
        '''
        # 更新参数
        param = np.loadtxt(xajparm_path,dtype=np.float32)
        for i,index in enumerate(change_list):
            param[index-1,2] = paras[i]
        parameters =  param[:,2]
        np.savetxt(xajparm_path, param,fmt='%.4f', delimiter=' ', newline='\n', header='', footer='', comments='# ')

        p = np.loadtxt(data_force_path,dtype=np.float32)[:,0]
        e0 = np.loadtxt(data_force_path,dtype=np.float32)[:,1]
        f = np.loadtxt(data_force_path,dtype=np.float32)[0,2]

        predict_q = xaj.lumped_xaj(p,e0,f,parameters)

        return predict_q 

    def simulation(self,x):
        paras = [x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],x[8],x[9],x[10],x[11],x[12],x[13]]
        return self.calculate(paras)

    def evaluation(self):
        return self.real_value

    def objectivefunction(self, simulation, evaluation, params=None):
        #dc = 1-self.dc_calculate(simulation,evaluation)
        indices = np.loadtxt(Q_obs_path,dtype=np.int16)[:,1]+365
        return self.dc_calculate(simulation[indices],evaluation)